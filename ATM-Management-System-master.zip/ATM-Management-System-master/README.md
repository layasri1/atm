# ATM-Management-System
A semester project completed in Java Programming language


#Instructions

To run this file simple run the AtmMainDriver file first. No need to download pacakages. The username for both "Admin " & "User" is zahid and password for both is 1234.

Just simple run the "admin" first ato create the account first and use whatever you want in that.

But for "user" you can only withdraw , Check & transfer balance from one account to another.

